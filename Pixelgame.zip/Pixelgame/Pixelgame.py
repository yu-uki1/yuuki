import customtkinter as ctk
from PIL import Image, ImageTk
import random
import json
import os
import threading

# --- Grundeinstellungen ---
WORLD_SIZE = 1500
VIEW_SIZE = 10
TILE_SIZE = 100
player_x, player_y = 100, 100
max_health = 10
current_health = 10
max_armor = 10
current_armor = 0
max_mana = 10
current_mana = 0
is_dead = False
is_confused = False
confusion_timer = None
current_xp = 0
current_level = 1





SAVE_FILE = "savegame.json"

# Welt: 0=Gras, 1=Mauer
world = [[random.choice([0,0,0,1]) for _ in range(WORLD_SIZE)] for _ in range(WORLD_SIZE)]
         

# --- GUI Setup ---
ctk.set_appearance_mode("dark")
root = ctk.CTk()
root.title("2D Welt mit Charakter, Truhen & Inventar")
canvas = ctk.CTkCanvas(root, width=VIEW_SIZE*TILE_SIZE, height=VIEW_SIZE*TILE_SIZE, bg="black", highlightthickness=0)
canvas.pack()

# --- Hilfsfunktion: lade & skaliere Bild ---
def load_sprite(path, size=TILE_SIZE):
    img = Image.open(path)
    img = img.resize((size, size), Image.Resampling.NEAREST)
    return ImageTk.PhotoImage(img)

# --- Tiles laden ---
sprites = {0: load_sprite("grass.jpg"), 1: load_sprite("wall.jpg")}

# --- Spielfigur laden ---
player_sprite = load_sprite("character.png")

# --- Truhen laden ---
chest_sprite = load_sprite("chest.png")

# --- Herzen laden ---
heart_sprite_full = load_sprite("heart_full.png", size=50)
heart_sprite_empty = load_sprite("heart_empty.png", size=50)

# --- Rüstungen laden ---
armor_sprite_full = load_sprite("chestplate_full.png", size=50)
armor_sprite_empty = load_sprite("chestplate_empty.png", size=50)

# --- Items laden ---
item_sprites = {
    "Heiltrank der Morgenröte": load_sprite("heiltrank_der_morgenröte.png", size=int(TILE_SIZE*0.9)),
    "Mana-Elixier": load_sprite("mana_elixier.png", size=int(TILE_SIZE*0.9)),
    "Verwirrungstrank": load_sprite("verwirrungstrank.png", size=int(TILE_SIZE*0.9)),
    "Flammenbombe": load_sprite("flammenbombe.png", size=int(TILE_SIZE*0.9)),
    "Beschädigtes Samuraischwert": load_sprite("kaputtes_samuraischwert.png", size=int(TILE_SIZE*0.9)),
    "Redbull": load_sprite("redbull.png", size=int(TILE_SIZE*0.9)),
    "Burger": load_sprite("burger.png", size=int(TILE_SIZE*0.9)),
    "Veggie-Burger": load_sprite("burger.png", size=int(TILE_SIZE*0.9)),
    "Zollstock": load_sprite("zollstock.png", size=int(TILE_SIZE*0.9)),
    "Gorbatschow-Vodka": load_sprite("vodka.png", size=int(TILE_SIZE*0.9)),
    "Bio-Tonne": load_sprite("biotonne.png", size=int(TILE_SIZE*0.9)),
    "Fire-TV Stick": load_sprite("firetvstick.png", size=int(TILE_SIZE*0.9)),
    "Premium-Highspeed-HDMI-Kabel": load_sprite("hdmi.png", size=int(TILE_SIZE*0.9)),
    "Gammel-Kakao": load_sprite("kakao.png", size=int(TILE_SIZE*0.9)),
    "Runensteine": load_sprite("runenstein.png", size=int(TILE_SIZE*0.9)),
    "Holz": load_sprite("holz.png", size=int(TILE_SIZE*0.9)),
    "Loser-Los": load_sprite("loser.png", size=int(TILE_SIZE*0.9)),
    "Ranzige Milch": load_sprite("milch.png", size=int(TILE_SIZE*0.9)),
    "Eisen": load_sprite("eisen.png", size=int(TILE_SIZE*0.9)),
    "Ast": load_sprite("ast.png", size=int(TILE_SIZE*0.9)),
    "Sprungboots": load_sprite("boots.png", size=int(TILE_SIZE*0.9)),
    "Rüstung des Ewigen Lichts": load_sprite("rüstung_licht.png", size=int(TILE_SIZE*0.9)),
    "Einäscherungszepter": load_sprite("zepter.png", size=int(TILE_SIZE*0.9)),
    "Zeitkristall": load_sprite("kristall_zeit.png", size=int(TILE_SIZE*0.9)),
    "Eisstreitkolben": load_sprite("streitkolben.png", size=int(TILE_SIZE*0.9)),
    "Laub": load_sprite("laub.png", size=int(TILE_SIZE*0.9)),
    "Switch 2": load_sprite("switch2.png",size=int(TILE_SIZE*0.9)),
}

# --- Items nach Rarität ---
common_items = ["Heiltrank der Morgenröte", "Mana-Elixier", "Gummihammer", "Sprungboots", "Pixel-Pfeil", "Flutlichtstrahler", "Gummihemd", "Zollstock", "Veggie-Burger", "Ranzige Milch", "Gorbatschow-Vodka", "Ast", "Laub", "Holz", "LAN-Kabel", "Kaputtes LAN-Kabel", "Bio-Tonne", "Leere Tonne", "Göffel", "Burger", "Eisen", "Gold", "Regenbogensternenstaub", "Eimer voll Pech", "Loser-Los", "Gammel-Kakao"]
uncommon_items = ["Eisstreitkolben", "Dornenrüstung", "Bumerang-Klinge", "Flammenbombe", "Verwirrungstrank"]
rare_items = ["Flammenschwert", "Schild der Reflexion", "Zeitkristall", "Katapult-Kürbis", "Einäscherungszepter", "Powerbank", "Beschädigtes Samuraischwert"]
epic_items = ["Donnerspeer", "Unsichtbarkeitspanzer", "Runensteine", "Schlüssel der Schattenkammer", "Kristallfragmente", "Redbull"]
legendary_items = ["Rüstung des Ewigen Lichts", "Premium-Highspeed-HDMI-Kabel", "Chakra-Kristall"]
god_items = ["Fire-TV Stick", "Echo Dot", "Switch 2"]
unreal_items = ["Regenbogenteppichmesser"]

# --- Truhen erstellen ---
chests = []

def random_empty_position():
    while True:
        x = random.randint(0, WORLD_SIZE-1)
        y = random.randint(0, WORLD_SIZE-1)
        if world[y][x] == 0:
            return (x, y)

for _ in range(20000):
    chests.append({"pos": random_empty_position(), "rarity": "Common", "items": random.sample(common_items, k=1)})
for _ in range(8000):
    chests.append({"pos": random_empty_position(), "rarity": "Uncommon", "items": random.sample(uncommon_items, k=1)})
for _ in range(4000):
    chests.append({"pos": random_empty_position(), "rarity": "Rare", "items": random.sample(rare_items, k=1)})
for _ in range(2000):
    chests.append({"pos": random_empty_position(), "rarity": "Epic", "items": random.sample(epic_items, k=1)})
for _ in range(1000):
    chests.append({"pos": random_empty_position(), "rarity": "Legendary", "items": random.sample(legendary_items, k=1)})
for _ in range(500):
    chests.append({"pos": random_empty_position(), "rarity": "God", "items": random.sample(god_items, k=1)})
for _ in range(10):
    chests.append({"pos": random_empty_position(), "rarity": "Unreal", "items": random.sample(unreal_items, k=1)})

# --- Inventar & Ausrüstung ---
inventory_open = False
INVENTORY_ROWS = 4
INVENTORY_COLS = 10
inventory = [None] * (INVENTORY_ROWS * INVENTORY_COLS)
equipment_slots = [None, None]
selected_equipment_slot = 0
selected_item = None
selected_index = None
selected_is_equipment = False

# --- Inventar zeichnen ---
def draw_inventory():
    canvas.delete("inventory")
    slot_size = TILE_SIZE * 0.9
    padding = 10
    if inventory_open:
        start_x = (canvas.winfo_width() - 2 * (slot_size + padding) + padding) // 2
        start_y = 50
        for i, item in enumerate(equipment_slots):
            x = start_x + i * (slot_size + padding)
            y = start_y
            canvas.create_rectangle(x, y, x+slot_size, y+slot_size, fill="darkgray", outline="black", width=3, tags="inventory")
            if item is not None:
                canvas.create_text(x+slot_size/2, y+slot_size/2, text=item, fill="white", font=("Arial", 12), tags="inventory")

        start_y = 150
        start_x = (canvas.winfo_width() - (INVENTORY_COLS * slot_size + (INVENTORY_COLS-1)*padding)) // 2
        for row in range(INVENTORY_ROWS):
            for col in range(INVENTORY_COLS):
                index = row * INVENTORY_COLS + col
                x = start_x + col * (slot_size + padding)
                y = start_y + row * (slot_size + padding)
                canvas.create_rectangle(x, y, x+slot_size, y+slot_size, fill="gray", outline="black", width=3, tags="inventory")
                item = inventory[index]
                if item is not None:
                    if item in item_sprites:
                        canvas.create_image(x+slot_size/2, y+slot_size/2, image=item_sprites[item], anchor="center", tags="inventory")
                    else:
                        canvas.create_text(x+slot_size/2, y+slot_size/2, text=item, fill="white", font=("Arial", 12), tags="inventory")


#--- XP-Leiste ---
def add_xp(amount):
    global current_xp, current_level
    current_xp += amount
    while current_xp >= 10 + (current_level - 1):
        current_xp -= 10 + (current_level - 1)
        current_level += 1


# --- Manaanzeige ---
def draw_mana():
    padding = 10
    bar_width = 360
    bar_height = 40
    spacing = 5

    x = padding
    y = padding + 40  # Unterhalb der Herzen
    
    if is_confused:
        fill_width = 0
        mana_text = "0/10 MP"
    else:
        fill_width = int((current_mana / max_mana) * bar_width)
        mana_text = f"{current_mana}/{max_mana} MP"


    # Hintergrund des Balkens
    canvas.create_rectangle(x, y, x + bar_width, y + bar_height, fill="gray", outline="black")

    # Füllung je nach aktuellem Mana
    fill_width = int((current_mana / max_mana) * bar_width)
    canvas.create_rectangle(x, y, x + fill_width, y + bar_height, fill="blue", outline="black")

    # Textanzeige der Punkte
    canvas.create_text(x + bar_width/2, y + bar_height/2, text=f"{current_mana}/{max_mana} MP", fill="white", font=("Arial", 12))
    



#--- XP-Bar ---
def draw_xp_bar():
    bar_width = 500  # passt zu den 2 Slots darunter
    bar_height = 30
    padding = 5
    slot_size = TILE_SIZE * 0.8
    start_y = canvas.winfo_height() - slot_size - bar_height - 30  # direkt über den Slots
    start_x = (canvas.winfo_width() - bar_width) // 2  # mittig

    # XP für das aktuelle Level
    needed_xp = 10 + (current_level - 1)
    fill_width = int((current_xp / needed_xp) * bar_width)

    # Hintergrund
    canvas.create_rectangle(start_x, start_y, start_x + bar_width, start_y + bar_height, fill="gray", outline="black")

    # Füllung
    canvas.create_rectangle(start_x, start_y, start_x + fill_width, start_y + bar_height, fill="green", outline="black")

    # Textanzeige Level und verbleibende XP
    remaining_xp = needed_xp - current_xp
    canvas.create_text(start_x + bar_width/2, start_y + bar_height/2,
                       text=f"Level {current_level} | {remaining_xp} XP bis Level up",
                       fill="white", font=("Arial", 12))



# --- Ausrüstung unten ---
def draw_equipment_bottom():
    slot_size = TILE_SIZE * 0.8
    padding = 10
    start_x = (canvas.winfo_width() - 2 * (slot_size + padding) + padding) // 2
    start_y = canvas.winfo_height() - slot_size - 20
    for i, item in enumerate(equipment_slots):
        x = start_x + i * (slot_size + padding)
        y = start_y
        outline_color = "yellow" if i == selected_equipment_slot else "black"
        canvas.create_rectangle(x, y, x+slot_size, y+slot_size, fill="darkgray", outline=outline_color, width=3)
        if item is not None:
            canvas.create_text(x+slot_size/2, y+slot_size/2, text=item, fill="white", font=("Arial", 12))


#--- Todeffektfade ---
def update_death_fade():
    global death_fade
    if is_dead and death_fade < 1:
        death_fade += 0.02  # Geschwindigkeit des Einblendens
        if death_fade > 1:
            death_fade = 1
        draw_world()
        root.after(50, update_death_fade)  # alle 50 ms leicht erhöhen


# --- Klick im Inventar/Ausrüstung ---
def inventory_click(event):
    global selected_item, selected_index, selected_is_equipment
    slot_size = TILE_SIZE * 0.9
    padding = 10
    if not inventory_open:
        return

    start_x = (canvas.winfo_width() - 2 * (slot_size + padding) + padding) // 2
    start_y = 50
    for i, item in enumerate(equipment_slots):
        x1, y1 = start_x + i * (slot_size + padding), start_y
        x2, y2 = x1 + slot_size, y1 + slot_size
        if x1 <= event.x <= x2 and y1 <= event.y <= y2:
            if selected_item is None and item is not None:
                selected_item = item
                selected_index = i
                selected_is_equipment = True
                equipment_slots[i] = None
            elif selected_item is not None:
                equipment_slots[i] = selected_item
                selected_item = None
            draw_world()
            return

    start_y = 150
    start_x = (canvas.winfo_width() - (INVENTORY_COLS * slot_size + (INVENTORY_COLS-1)*padding)) // 2
    for row in range(INVENTORY_ROWS):
        for col in range(INVENTORY_COLS):
            index = row * INVENTORY_COLS + col
            x1, y1 = start_x + col * (slot_size + padding), start_y + row * (slot_size + padding)
            x2, y2 = x1 + slot_size, y1 + slot_size
            if x1 <= event.x <= x2 and y1 <= event.y <= y2:
                if selected_item is None and inventory[index] is not None:
                    selected_item = inventory[index]
                    selected_index = index
                    selected_is_equipment = False
                    inventory[index] = None
                elif selected_item is not None:
                    inventory[index] = selected_item
                    selected_item = None
                draw_world()
                return

canvas.bind("<Button-1>", lambda e: inventory_click(e))

def end_confusion():
    global is_confused
    is_confused = False
    draw_world()  # Anzeige sofort zurücksetzen

# Globale Variable
permanent_health_mod = 0

def use_item(slot_index):
    global permanent_health_mod
    global current_mana, max_mana

    item = equipment_slots[slot_index]
    if item is None:
        return

    # Verbrauchsitems
    if item == "Ranzige Milch":
        permanent_health_mod -= 6
        equipment_slots[slot_index] = None
    elif item == "Veggie-Burger":
        permanent_health_mod -= 1
        equipment_slots[slot_index] = None
    elif item == "Gorbatschow-Vodka":
        permanent_health_mod -= 4
        current_mana = min(max_mana, current_mana + 4)
        equipment_slots[slot_index] = None
    elif item == "Burger":
        permanent_health_mod += 3
        equipment_slots[slot_index] = None
    elif item == "Heiltrank der Morgenröte":
        permanent_health_mod += 1
        equipment_slots[slot_index] = None
    elif item == "Redbull":
        permanent_health_mod -= 1
        equipment_slots[slot_index] = None
    elif item == "Gammel-Kakao":
        permanent_health_mod -= 5
        equipment_slots[slot_index] = None
    elif item == "Mana-Elixier":
        current_mana = min(max_mana, current_mana + 3)
        equipment_slots[slot_index] = None
    elif item == "Verwirrungstrank":
            global is_confused, confusion_timer
            is_confused = True
            equipment_slots[slot_index] = None

            # Timer starten, nach 10 Sekunden Verwirrung aufheben
            if confusion_timer:
                confusion_timer.cancel()  # alten Timer stoppen, falls noch aktiv
            confusion_timer = threading.Timer(10.0, end_confusion)
            confusion_timer.start()


    # Ausrüstungsitems bleiben im Slot
    elif item in ["Gummihammer", "Sprungboots", "Pixel-Pfeil", "Flutlichtstrahler", "Gummihemd", "Zollstock", "Ast", "Laub", "Holz", "LAN-Kabel", "Kaputtes LAN-Kabel", "Bio-Tonne", "Leere Tonne", "Göffel", "Eisen", "Gold", "Regenbogensternenstaub", "Eimer voll Pech", "Loser-Los", "Eisstreitkolben", "Dornenrüstung", "Bumerang-Klinge","Flammenschwert", "Schild der Reflexion", "Zeitkristall", "Katapult-Kürbis", "Einäscherungszepter", "Powerbank", "Beschädigtes Samuraischwert", "Donnerspeer", "Unsichtbarkeitspanzer", "Runensteine", "Schlüssel der Schattenkammer", "Kristallfragmente", "Rüstung des Ewigen Lichts", "Premium-Highspeed-HDMI-Kabel", "Chakra-Kristall", "Fire-TV Stick", "Echo Dot", "Switch 2", "Regenbogenteppichmesser"]:
        pass  # Effekt wird automatisch durch draw_armor() angezeigt
    
    



# --- Lebensanzeige ---

def draw_health():
    global is_dead
    padding = 10
    heart_size = 30
    spacing = 5

    if is_confused:
        effective_health = 0  # vortäuschen
    else:
        effective_health = current_health + permanent_health_mod
        effective_health = max(0, min(max_health, effective_health))

    # Anzeige zeichnen
    for i in range(max_health):
        x = padding + i * (heart_size + spacing)
        y = padding
        sprite = heart_sprite_full if i < effective_health else heart_sprite_empty
        canvas.create_image(x, y, image=sprite, anchor="nw")

    # Prüfen, ob Spieler gestorben ist
    if not is_confused and effective_health <= 0:
        is_dead = True


# --- Rüstungsanzeige ---
def draw_armor():
    padding = 10
    armor_size = 30
    spacing = 5
    if is_confused:
        effective_armor = 0
    else:
        armor_from_equipment = 0
        if equipment_slots[0] == "Sprungboots": armor_from_equipment = 2
        elif equipment_slots[0] == "Dornenrüstung": armor_from_equipment = 4
        elif equipment_slots[0] == "Schild der Reflexion": armor_from_equipment = 7
        elif equipment_slots[0] == "Rüstung des Ewigen Lichts": armor_from_equipment = 10
        effective_armor = max(current_armor, armor_from_equipment)

    for i in range(max_armor):
        x = canvas.winfo_width() - padding - (i + 1) * (armor_size + spacing)
        y = padding
        sprite = armor_sprite_full if i < effective_armor else armor_sprite_empty
        canvas.create_image(x, y, image=sprite, anchor="nw")

# --- Welt zeichnen ---

def draw_world():
    canvas.delete("all")
    start_x = max(0, player_x - VIEW_SIZE//2)
    start_y = max(0, player_y - VIEW_SIZE//2)
    if start_x + VIEW_SIZE > WORLD_SIZE:
        start_x = WORLD_SIZE - VIEW_SIZE
    if start_y + VIEW_SIZE > WORLD_SIZE:
        start_y = WORLD_SIZE - VIEW_SIZE

    # Normal Welt zeichnen
    for row in range(VIEW_SIZE):
        for col in range(VIEW_SIZE):
            world_x = start_x + col
            world_y = start_y + row
            tile = world[world_y][world_x]
            x = col*TILE_SIZE
            y = row*TILE_SIZE
            canvas.create_image(x, y, image=sprites[tile], anchor="nw")

    for chest in chests:
        chest_x, chest_y = chest["pos"]
        if start_x <= chest_x < start_x + VIEW_SIZE and start_y <= chest_y < start_y + VIEW_SIZE:
            cx = (chest_x - start_x) * TILE_SIZE
            cy = (chest_y - start_y) * TILE_SIZE
            canvas.create_image(cx, cy, image=chest_sprite, anchor="nw")

    px = (player_x - start_x) * TILE_SIZE
    py = (player_y - start_y) * TILE_SIZE
    canvas.create_image(px, py, image=player_sprite, anchor="nw")

    for chest in chests:
        chest_x, chest_y = map(int, chest["pos"])
        if (player_x, player_y) == (chest_x, chest_y):
            canvas.create_text(VIEW_SIZE*TILE_SIZE//2, 20, text=f"{chest['rarity']} Truhe!", fill="black", font=("Arial", 25), anchor="n")
            break
    draw_xp_bar()

        
    # Beispiel: Biotonnen auf der Karte zeichnen
    for x in range(WORLD_SIZE):
        for y in range(WORLD_SIZE):
            if world[y][x] == 2:  # 2 = Biotonne
                if start_x <= x < start_x + VIEW_SIZE and start_y <= y < start_y + VIEW_SIZE:
                    bx = (x - start_x) * TILE_SIZE
                    by = (y - start_y) * TILE_SIZE
                    canvas.create_image(bx, by, image=item_sprites["Bio-Tonne"], anchor="nw")


    draw_health()
    draw_mana()
    draw_armor()
    if inventory_open:
        draw_inventory()
    draw_equipment_bottom()

    # Wenn tot, Bildschirm transparent rot überlagern und Nachricht anzeigen
    if is_dead:
        canvas.create_rectangle(0, 0, VIEW_SIZE*TILE_SIZE, VIEW_SIZE*TILE_SIZE, fill="red", stipple="gray50")
        canvas.create_text(VIEW_SIZE*TILE_SIZE//2, VIEW_SIZE*TILE_SIZE//2, text="Du bist gestorben", fill="white", font=("Arial", 40))


# --- Bewegung ---
def move_player(dx, dy):
    global player_x, player_y
    if is_dead:
        return  # keine Bewegung, wenn tot
    new_x = player_x + dx
    new_y = player_y + dy
    if 0 <= new_x < WORLD_SIZE and 0 <= new_y < WORLD_SIZE:
        if world[new_y][new_x] != 1:
            player_x, player_y = new_x, new_y
    draw_world()

# --- Truhe aufnehmen ---

def remove_chest(event):
    global chests, inventory
    for chest in chests:
        chest_x, chest_y = map(int, chest["pos"])
        if (player_x, player_y) == (chest_x, chest_y):
            for item in chest["items"]:
                for i in range(len(inventory)):
                    if inventory[i] is None:
                        inventory[i] = item
                        break
            chests.remove(chest)
            
            # 1 XP beim Öffnen der Truhe
            add_xp(1)
            
            break
    draw_world()

# --- Spiel speichern ---
def save_game():
    data = {
        "player_x": player_x,
        "player_y": player_y,
        "current_health": current_health,
        "current_armor": current_armor,
        "permanent_health_mod": permanent_health_mod,
        "inventory": inventory,
        "equipment_slots": equipment_slots,
        "chests": [{"pos": chest["pos"], "rarity": chest["rarity"], "items": chest["items"]} for chest in chests],
        "world": world,
        "current_xp": current_xp,     
        "current_level": current_level
    }
    with open(SAVE_FILE, "w") as f:
        json.dump(data, f)
    print("Spiel gespeichert!")

# --- Spiel laden ---
def load_game():
    global player_x, player_y, current_level, current_xp, current_health, current_armor, inventory, equipment_slots, chests, world, is_dead, permanent_health_mod
    if os.path.exists(SAVE_FILE):
        with open(SAVE_FILE, "r") as f:
            data = json.load(f)
            player_x = data["player_x"]
            player_y = data["player_y"]
            permanent_health_mod = data["permanent_health_mod"]
            current_health = data.get("current_health", 10)
            current_armor = data["current_armor"]
            inventory = data["inventory"]
            equipment_slots = data["equipment_slots"]
            world = data["world"]
            current_xp = data["current_xp"]
            current_level = data ["current_level"]
            chests = []
            for chest in data["chests"]:
                pos = tuple(map(int, chest["pos"]))
                chests.append({"pos": pos, "rarity": chest["rarity"], "items": chest["items"]})
        is_dead = False  # Spieler wieder lebendig
        draw_world()
        print("Spiel geladen!")
    else:
        print("Keine gespeicherte Datei gefunden.")

# --- Inventar öffnen/schließen ---
def toggle_inventory(event):
    global inventory_open
    inventory_open = not inventory_open
    draw_world()

# --- Steuerung ---
def key_pressed(event):
    global selected_equipment_slot
    if event.keysym == "w": move_player(0, -1)
    elif event.keysym == "s": move_player(0, 1)
    elif event.keysym == "a": move_player(-1, 0)
    elif event.keysym == "d": move_player(1, 0)
    elif event.keysym == "Tab": remove_chest(event)
    elif event.keysym.lower() == "e": toggle_inventory(event)
    elif event.keysym.lower() == "k": save_game()
    elif event.keysym.lower() == "l": load_game()
    elif event.keysym == "1": selected_equipment_slot = 0; draw_world()
    elif event.keysym == "2": selected_equipment_slot = 1; draw_world()
    elif event.keysym == "space": use_item(selected_equipment_slot); draw_world()

root.bind("<Key>", key_pressed)

# --- Automatisches Speichern alle 5 Minuten, erst 5 Minuten nach Start ---
def auto_save():
    save_game()
    root.after(300000, auto_save)  # alle 5 Minuten

root.after(300000, auto_save)  # Start nach 5 Minuten

draw_world()
root.mainloop()


